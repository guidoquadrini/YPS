<?php

$config['acl_site_permissions'] = ['public', 'registered'];