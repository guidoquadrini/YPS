<h2>Test de lenguaje</h2>

<hr>

<p><?= $this->lang->line('cms_general_label_id'); ?>: <?= $this->user->id; ?></p>
<p><?= $this->lang->line('cms_general_label_user'); ?>: <?= $this->user->user; ?></p>
<p><?= $this->lang->line('cms_general_label_name'); ?>: <?= $this->user->name; ?></p>
<p><?= $this->lang->line('cms_general_label_email'); ?>: <?= $this->user->email; ?></p>