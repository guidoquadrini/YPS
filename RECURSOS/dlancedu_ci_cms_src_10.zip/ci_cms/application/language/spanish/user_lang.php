<?php

// errors
$lang['user_error_invalid_user'] = 'Usuario no válido';
$lang['user_error_username'] = 'Nombre de usuario no válido';
$lang['user_error_empty_password'] = 'Debe ingresar la contraseña';
$lang['user_error_wrong_credentials'] = 'Usuario y/o contraseña incorrectos';