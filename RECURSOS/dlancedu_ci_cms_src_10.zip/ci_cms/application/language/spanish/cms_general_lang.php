<?php

// etiquetas

$lang['cms_general_label_id'] = 'Id';
$lang['cms_general_label_user'] = 'Usuario';
$lang['cms_general_label_password'] = 'Contraseña';
$lang['cms_general_label_email'] = 'Correo';
$lang['cms_general_label_name'] = 'Nombre';
$lang['cms_general_label_site_visitor_name'] = 'Invitado';
$lang['cms_general_label_site_visitor_user'] = 'anonimo';
$lang['cms_general_label_button_access'] = 'Acceder';