<?php

// errors
$lang['user_error_invalid_user'] = 'Invalid user';
$lang['user_error_username'] = 'Invalid username';
$lang['user_error_empty_password'] = 'Password is required';
$lang['user_error_wrong_credentials'] = 'Login incorrect';