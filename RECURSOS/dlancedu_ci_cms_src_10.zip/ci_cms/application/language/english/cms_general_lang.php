<?php

// etiquetas

$lang['cms_general_label_id'] = 'Id';
$lang['cms_general_label_user'] = 'User';
$lang['cms_general_label_password'] = 'Password';
$lang['cms_general_label_email'] = 'Email';
$lang['cms_general_label_name'] = 'Name';
$lang['cms_general_label_site_visitor_name'] = 'Guest';
$lang['cms_general_label_site_visitor_user'] = 'anonymous';
$lang['cms_general_label_button_access'] = 'Access';