## Welcome to Bonfire

These documents should help you get up to speed with Bonfire in the fastest time possible.

To get started, follow along with one of these guides:

### [Getting Started Guide](docs/bonfire/getting_started_with_bonfire)

New to Bonfire? This guide will help you to understand the basics of the system.

### [Using the Module Builder](docs/builder)

Learn how to create your apps even faster by letting Bonfire build the skeleton code for  you.