<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Allows viewing of log files and adjusting log level.',
	'author'		=> 'Bonfire Team',
	'name'			=> 'Logs'
);	