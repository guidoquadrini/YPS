<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$route['docs/(:any)'] = 'docs';