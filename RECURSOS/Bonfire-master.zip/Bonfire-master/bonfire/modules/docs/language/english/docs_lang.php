<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$lang['docs_title_application'] = 'Application';
$lang['docs_title_bonfire']     = 'Bonfire';
$lang['docs_title_modules']     = 'Modules';

$lang['docs_not_found']         = 'Unable to find the docs you were looking for.';