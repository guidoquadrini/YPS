<ul>
	<li><a href="<?php echo site_url(SITE_AREA .'/developer/database') ?>">Maintenance</a></li>
	<li><a href="<?php echo site_url(SITE_AREA .'/developer/database/backups') ?>">Backups</a></li>
</ul>
