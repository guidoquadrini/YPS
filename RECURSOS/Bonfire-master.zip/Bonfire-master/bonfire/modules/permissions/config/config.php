<?php if (!defined('BASEPATH')) exit('No direct script access allowed');

$config['module_config'] = array(
	'description'	=> 'Manages the Permissions available to the Roles.',
	'author'		=> 'Bonfire Team'
);