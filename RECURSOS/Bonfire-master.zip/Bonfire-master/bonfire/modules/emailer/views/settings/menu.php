<ul>
	<li><a href="<?php echo site_url(SITE_AREA .'/settings/emailer') ?>">Settings</a></li>
	<li><a href="<?php echo site_url(SITE_AREA .'/settings/emailer/template') ?>">Template</a></li>
	<li><a href="<?php echo site_url(SITE_AREA .'/settings/emailer/queue') ?>">View Queue</a></li>
</ul>
