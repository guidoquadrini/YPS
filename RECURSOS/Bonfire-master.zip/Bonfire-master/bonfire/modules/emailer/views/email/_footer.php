						</td>
					</tr>

					<tr>
						<td style="background-color:#fff;border-top:1px solid #ccc;" valign="top">
							Copyright (C) 2013  All rights reserved.
						</td>
					</tr>

				</table>

			</td>
		</tr>
	</table>
</body>
</html>
