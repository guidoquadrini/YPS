<?php

$lang['acl_error_permission_not_found'] = 'Permiso no encontrado';