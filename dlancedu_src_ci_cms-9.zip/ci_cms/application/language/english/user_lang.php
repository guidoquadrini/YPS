<?php

// errors
$lang['user_error_invalid_user'] = 'Invalid user';