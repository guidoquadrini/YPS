<?php

$lang['acl_error_permission_not_found'] = 'Permission not found';